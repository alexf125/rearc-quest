import json
import os
import time
import logging
import requests

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
DATABRICKS_INSTANCE = os.environ["DATABRICKS_INSTANCE"].rstrip("/")
DATABRICKS_TOKEN    = os.environ["DATABRICKS_TOKEN"]
DATABRICKS_JOB_ID   = os.environ["DATABRICKS_JOB_ID"]

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json"
}

# Helper: get notebook output by task_run_id
def get_task_output(task_run_id, max_retries=5, delay=3):
    """
    Safely get notebook output for a specific task run ID.
    Retries on 400 errors (common due to Databricks timing issues).
    """
    for attempt in range(max_retries):
        resp = requests.get(
            f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get-output",
            headers=HEADERS,
            params={"run_id": task_run_id}
        )
        if resp.status_code == 400:
            logger.warning(
                "Databricks 400 Bad Request for task_run_id=%s, retrying in %s seconds...",
                task_run_id, delay
            )
            time.sleep(delay)
            continue
        resp.raise_for_status()
        return resp.json()
    raise Exception(f"Failed to get notebook output after {max_retries} retries for task_run_id {task_run_id}")

# Lambda handler
def lambda_handler(event, context):
    logger.info("Received SQS event: %s", json.dumps(event))

    for record in event["Records"]:
        try:
            message_body = record["body"]
            logger.info("Processing SQS message: %s", message_body)

            # Trigger the Databricks job
            run_now_payload = {
                "job_id": DATABRICKS_JOB_ID,
                "notebook_params": {}  # Optional: pass SQS message if needed
            }
            response = requests.post(
                f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now",
                headers=HEADERS,
                data=json.dumps(run_now_payload)
            )
            response.raise_for_status()
            run_id = response.json()["run_id"]
            logger.info("Triggered Databricks job, run_id=%s", run_id)

            # Poll for job completion
            max_attempts = 120  # ~10 minutes
            attempt = 0
            while attempt < max_attempts:
                status_resp = requests.get(
                    f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get",
                    headers=HEADERS,
                    params={"run_id": run_id}
                )
                status_resp.raise_for_status()
                run_data = status_resp.json()
                run_state = run_data.get("state", {})
                life_cycle_state = run_state.get("life_cycle_state")
                result_state = run_state.get("result_state")

                logger.info("Run state: %s", life_cycle_state)

                if life_cycle_state == "TERMINATED":
                    if result_state != "SUCCESS":
                        logger.error("Databricks job failed: %s", run_state)
                        break
                    # short pause to ensure task_run outputs are ready
                    time.sleep(2)
                    break

                attempt += 1
                time.sleep(5)
            else:
                logger.error("Databricks job did not complete in time (run_id=%s)", run_id)
                continue

            if result_state != "SUCCESS":
                continue  # skip if job failed

            # Retrieve outputs for all tasks
            tasks = run_data.get("tasks", [])
            if not tasks:
                logger.warning("No tasks found in job run data, using top-level run_id")
                tasks = [{"task_run_id": run_id}]

            for task in tasks:
                task_run_id = task.get("run_id")
                if not task_run_id:
                    logger.warning("Skipping task without task_run_id: %s", task)
                    continue

                # Get notebook output for this task
                try:
                    output_json = get_task_output(task_run_id)
                    notebook_result = output_json.get("notebook_output", {}).get("result")
                    if not notebook_result:
                        logger.warning("No output returned for task_run_id=%s", task_run_id)
                        continue

                    # Parse JSON
                    try:
                        results = json.loads(notebook_result)
                    except Exception as e:
                        logger.error(
                            "Failed to parse notebook_result JSON for task_run_id=%s. Raw output: %s",
                            task_run_id, notebook_result
                        )
                        continue

                    # Log all reports
                    for report_key, report in results.items():
                        logger.info("===== %s =====", report.get("name", report_key))
                        logger.info("Row count: %s", report.get("row_count", 0))
                        logger.info("Rows:\n%s", json.dumps(report.get("rows", []), indent=2))

                except Exception as e:
                    logger.exception(
                        "Failed to retrieve notebook output for task_run_id=%s: %s",
                        task_run_id, e
                    )

        except Exception as e:
            logger.exception("Error processing SQS message: %s", e)

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Processed SQS messages"})
    }
